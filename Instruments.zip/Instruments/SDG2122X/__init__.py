from .core import SDG2122X

__all__ = ["SDG2122X"]